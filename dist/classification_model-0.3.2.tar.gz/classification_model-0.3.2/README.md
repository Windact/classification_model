# classification_model
A classification model package for faulty water pumps
